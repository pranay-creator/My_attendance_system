# Face Recognition and Attendance Project

[![Watch Video](https://github.com/murtazahassan/Face-Recognition/blob/master/tumbnail.jpg)](https://youtu.be/sz25xxF_AVE)

In this video we are going to learn how to perform Facial recognition with high accuracy. We will first briefly go through the theory and learn the basic implementation. Then we will create an Attendance project that will use webcam to detect faces and record the attendance live in an excel sheet. 


Product Links:

Tello Combo Pack: 

https://amzn.to/2TZpsJy

Tello:

https://amzn.to/2t4l2pW 

Recommend Webcam for Computer Vision:

https://amzn.to/2MNtVKZ

Budget Webcam:

https://amzn.to/2ZP47Ug

Links:

OpenCV Python Complete Course:

https://www.youtube.com/watch?v=CJXIjApHYVs&list=PLMoSUbG1Q_r_sc0x7ndCsqdIkL7dwrmNF

How to install Opencv in Python:

https://youtu.be/CJXIjApHYVs
